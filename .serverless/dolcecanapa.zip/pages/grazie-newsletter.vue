<template lang="html">
    <div class="has-text-centered grazieNewsletter">
        <h1 class="title is-1">Grazie!</h1>
        <p class="subtitle is-3">
            Iscrizione alla Newsletter avvenuta con successo!
        </p>
        <p>
            Riceverai una email mensile con tutte le novità e le istruzioni sul mondo della canapa legale.
        </p>

        <a href="/">Torna alla Home page del sito</a>
    </div>
</template>

<script>
export default {
}
</script>

<style lang="scss">
.grazieNewsletter {
    padding: 4rem;

    a {
        font-size: 220%;
    }
}
</style>
