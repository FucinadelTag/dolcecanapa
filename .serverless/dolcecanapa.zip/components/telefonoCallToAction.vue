<template lang="html">
    <section>
        <span class="is-size-2"> Ordina online e paga alla consegna</span>
        <div class="callToAction has-text-centered">
            <a href="tel:800 800 800 800" class="button is-large" alt="800-180-439"> 800-180-439</a>
        </div>
        <span class="is-size-4"><i>Da lunedì a venerdì - dalle 9 alle 18</i></span>

    </section>


</template>

<script>
export default {
}
</script>

<style lang="scss">
</style>
