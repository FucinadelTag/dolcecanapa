<template lang="html">

    <div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.2/jquery.min.js"></script>
        <script id="snipcart" src="https://cdn.snipcart.com/scripts/2.0/snipcart.js" data-api-key="NTExNDk1NmQtZTFkZS00MGMwLWI3MDItN2Y3ZmQ5ZGRkMDg3NjM2NjE1Nzk1Njg1OTI3MzI5"></script>
        <script src="/snipcart.js"></script>
    </div>


</template>

<script>

export default {
}
</script>

<style lang="css">
</style>
