<template lang="html">
    <footer class="footer">
        <div class="container">

            <div class="columns">
                <div class="column content">
                    <p class="title is-4">
                        Chi siamo
                    </p>
                    <p>
                        DolceCanapa.it è un team italiano di appassionati ed esperti nella lavorazione e vendita della cannabis legale in Italia.
                    </p>
                </div>
                <div class="column">

                    <p class="title is-4">
                        Dubbi o domande?
                    </p>
                    <p class="subtitle is-6">
                        Scrivici un messaggio<br>Ti risponderemo il prima possibile.
                    </p>
                    <section>
                        <form accept-charset="UTF-8" action="https://formkeep.com/f/4bca51bafe71" method="POST">
                            <div class="field">
                                <label class="label is-small">Email:</label>
                                <p class="control">
                                    <input required class="input" type="email" name="email" placeholder="Email">
                                </p>
                            </div>
                            <div class="field">
                                <label class="label is-small">Messaggio:</label>
                                <p class="control">
                                    <textarea required class="textarea" name="messaggio" placeholder="Messaggio"></textarea>
                                </p>
                            </div>
                            <div class="control has-text-centered">
                                <button class="button">Contattaci!</button>
                            </div>
                        </form>
                    </section>

                </div>
                <div class="column has-text-centered">
                    <p class="title is-4">
                        Privacy
                    </p>
                    <p>
                        <a href="//www.iubenda.com/privacy-policy/369660" class="iubenda-white no-brand iubenda-embed" title="Privacy Policy">Privacy Policy</a>
                    </p>
                    <br>
                    <p class="has-text-centered">
                        <strong>DolceCanapa.it</strong><br>è un progetto di <i>Fucina del Tag</i>
                        <p>
                            <br>Via Cislaghi 21
                            <br>20128 Milano
                            <br>P.IVA 03201900960
                        </p>

                     </p>
                </div>

            </div>
        </div>
    </footer>
</template>

<script>
</script>

<style lang="scss">
    .noteLegali {
        padding: 2rem;
    }
</style>
