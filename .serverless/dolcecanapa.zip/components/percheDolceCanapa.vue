<template lang="html">
    <section class="box">
        <div class="title is-2 line_bottom">
            Perchè scegliere <span class="verde">DolceCanapa.it</span>
        </div>
        <div class="columns is-5 is-variable is-multiline">
            <div class="column is-half">
                    <h3>
                        <i class="far fa-smile" aria-hidden="true"></i> 100% soddisfatti o rimborsati
                    </h3>
                    <p>
                        Acquista in totale tranquillità.<br>Hai 15 giorni per valutare e ripensare al tuo acquisto!<br>Nel caso volessi restutuire,
                        <strong>non dovrai pagare neanche le spese di spedizione</strong>.
                    </p>
            </div>
            <div class="column is-half">
                <h3>
                    <i class="fa fa-gavel" aria-hidden="true"></i> Acquista in modo <strong>legale e sicuro</strong>
                </h3>
                <p>
                    Le nostre infiorescenze  e i nostri olii di CBD <strong>rispettano la legge e le normative italiane</strong>
                </p>
            </div>
            <div class="column is-half">
                <h3>
                    <i class="far fa-handshake"></i> Assistenza al telefono: <strong>800-180-439</strong>
                </h3>
                <p>
                    Hai dubbi o domande?<br><strong>Chiamaci al numero verde 800-180-439!</strong> <br>Il nostro esperto ti fornirà tutte le informazioni.
                </p>
            </div>
            <div class="column is-half">
                <h3>
                    <i class="fa fa-credit-card" aria-hidden="true"></i> Pagamenti facili e sicuri!
                </h3>
                <div>
                    Puoi scegliere di pagare in tutta sicurezza:
                    <ul>
                        <li>
                            <strong>Carta di Credito</strong>
                        </li>
                        <li>
                            <strong>PayPal</strong>
                        </li>
                        <li>
                            <strong>Contrassegno</strong> (Paghi al momento della consegna)
                        </li>
                    </ul>
                </div>
            </div>
            <div class="column is-half">
                <h3>
                    <i class="fa fa-truck" aria-hidden="true"></i> Spedizione <strong>gratuita</strong> in <strong>24/48h</strong>
                </h3>
                <p>
                    Curiamo nel dettaglio ogni spedizione in modo tale da rendere il servizio migliore senza perdere tempo.<br>
                    I nostri ordini vengono consegnati in 24/48 ore.
                </p>
            </div>
            <div class="column is-half">
                <h3>
                    <i class="far fa-thumbs-up" aria-hidden="true"></i> Qualità del prodotto:
                </h3>
                <p>
                    Tutti i nostri prodotti sono ottenuti da Cannabis cresciuta su terreni <strong>organici e biologici certificati</strong>. Siamo contro lo sfruttamento intensivo del terreno, e rispettiamo sempre il ciclo naturale della pianta.
                </p>
            </div>
        </div>
    </section>

</template>

<script>
export default {
    props: ['include', 'indice'],
}
</script>

<style lang="css">
</style>
