export default ({ app }) => {
    var addthisScript = document.createElement('script');
    addthisScript.setAttribute('src', 'https://use.fontawesome.com/releases/v5.0.10/js/all.js');
    document.body.appendChild(addthisScript);
}
